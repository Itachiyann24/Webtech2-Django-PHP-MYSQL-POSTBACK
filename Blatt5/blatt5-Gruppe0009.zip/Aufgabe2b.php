<!DOCTYPE html>
<html>
<head>
    <style>
        table {
            border-collapse: collapse;
            z-index: 1;
            position: absolute;
        }
        td {
            padding: 10px;
            color: black;
        }
        .TV-Screen {
            position: relative;
            width: 230px;
            height: 200px;
            margin: 20px;
            background: white;
            border-radius: 60% / 30%;
            color: white;
            text-indent: .1em;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .TV-Screen::before {
            content: '';
            position: absolute;
            top: 8%;
            bottom: 8%;
            right: -1%;
            left: -1%;
            border-radius: 15% / 20%;
            z-index: -1;
        }
        .matrix-entry {
            color: black;
            position: relative;
            z-index: 1;
        }
    </style>
</head>
<body>
    <?php
    $n = 4;
    echo "<div class='TV-Screen'>";
    echo "<table>";
    for ($i = 1; $i <= $n; $i++) {
        echo "<tr>";
        for ($j = 1; $j <= $n; $j++) {
            $value = round (1 / ($i + $j-1),3);
            echo "<td class='matrix-entry'>" . $value . "</td>";
        }
        echo "</tr>";
    }
    echo "</table>";
    echo "</div>";
    ?>
</body>