<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <title>Bart Simpson Strafe</title>
    <style>
        body {
            background-color: brown;
            display: flex;
            justify-content: center;
            align-items: center;
            margin: 0;
        }
        .tafel {
            background-color: black;
            color: white;
            font-family: 'Comic Sans MS', 'Chalkboard', sans-serif;
            padding: 20px;
            border: 10px solid brown;
            width: 80%;
            box-sizing: border-box;
        }
        .line {
            margin: 5px 0;
        }
    </style>
</head>
<body>
    <div class="tafel">
        <?php
        $anzahl = intval(@$_GET['anzahl']);
        if ($anzahl <= 0) {
            $anzahl = 1; // Standardanzahl, falls ungültiger Wert übergeben wird
        }
        for ($i = 0; $i < $anzahl; $i++) {
            echo "<div class='line'>Ich werde keine Kreide verschwenden!</div>";
        }
        ?>
    </div>
</body>
</html>
