<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <title>Bart Simpson Strafe</title>
    <style>
        body {
            background-color: brown;
            display: flex;
            justify-content: center;
            align-items: center;
            margin: 0;
        }
        .tafel {
            background-color: black;
            color: white;
            font-family: 'Comic Sans MS', 'Chalkboard', sans-serif;
            padding: 20px;
            border: 10px solid brown;
            width: 80%;
            box-sizing: border-box;
        }
        .line {
            margin: 5px 0;
        }
    </style>
</head>
<body>
    <div class="tafel">
        <?php
        $anzahl = intval(@$_GET['anzahl']);
        if ($anzahl <= 0) {
            $anzahl = 1; // Standardanzahl, falls ungültiger Wert übergeben wird
        }
        $satz = htmlspecialchars(@$_GET['satz'], ENT_QUOTES, 'UTF-8');
        if (empty($satz)) {
            $satz = "Ich werde keine Kreide verschwenden!"; // Standardsatz, falls kein Satz übergeben wird
        }
        for ($i = 0; $i < $anzahl; $i++) {
            echo "<div class='line'>" . $satz . "</div>";
        }
        ?>
    </div>
</body>
</html>
