<?php
session_start();

// Sicherstellen, dass der Benutzer eingeloggt ist
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: admin.php');
    exit;
}

// Datenbankverbindung einbinden
require_once 'db_connect.php';

// Initialisierung der Variablen für Fehlermeldung und Erfolgsmeldung
$error = '';
$success_message = '';

// Überprüfen, ob die Matrikelnummer des Studenten per GET übergeben wurde
if (isset($_GET['matrnr'])) {
    $matrnr = $_GET['matrnr'];
    
    // Abfrage, um den Studenten zu finden
    $select_student_query = "SELECT * FROM Student WHERE MatrNr = ?";
    $stmt_student = mysqli_prepare($mysqli, $select_student_query);
    mysqli_stmt_bind_param($stmt_student, 'i', $matrnr);
    mysqli_stmt_execute($stmt_student);
    $result_student = mysqli_stmt_get_result($stmt_student);
    
    if (mysqli_num_rows($result_student) > 0) {
        // Student gefunden
        $student = mysqli_fetch_assoc($result_student);
    } else {
        // Fehlermeldung, wenn Student nicht gefunden wurde
        $error = 'Student nicht gefunden.';
    }
    
    mysqli_stmt_close($stmt_student);
}

// Abfrage für Vorlesungen
$select_vorlesungen_query = "SELECT VorlNr, Titel FROM Vorlesung";
$result_vorlesungen = mysqli_query($mysqli, $select_vorlesungen_query);

// Abfrage, welche Vorlesungen der Student bereits hört
$select_hoert_query = "SELECT VorlNr FROM hört WHERE MatrNr = ?";
$stmt_hoert = mysqli_prepare($mysqli, $select_hoert_query);
mysqli_stmt_bind_param($stmt_hoert, 'i', $matrnr);
mysqli_stmt_execute($stmt_hoert);
$result_hoert = mysqli_stmt_get_result($stmt_hoert);

$hört_vorlesungen = [];
while ($row = mysqli_fetch_assoc($result_hoert)) {
    $hört_vorlesungen[] = $row['VorlNr'];
}

mysqli_stmt_close($stmt_hoert);
?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <title>Vorlesungen zuweisen</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="admin-container">
        <h2>Vorlesungen zuweisen für <?php echo htmlspecialchars($student['Vorname'] . ' ' . $student['Nachname'] . ' (Matrikelnummer: ' . $student['MatrNr'] . ')'); ?></h2>
        <?php if (!empty($error)): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>
        <form method="post" action="assign.php">
            <input type="hidden" name="matrnr" value="<?php echo htmlspecialchars($matrnr); ?>">
            <table>
                <thead>
                    <tr>
                        <th>Vorlesungsnummer</th>
                        <th>Vorlesungstitel</th>
                        <th>Vorlesung hören</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = mysqli_fetch_assoc($result_vorlesungen)): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['VorlNr']); ?></td>
                            <td><?php echo htmlspecialchars($row['Titel']); ?></td>
                            <td><input type="checkbox" name="vorlesungen[]" value="<?php echo htmlspecialchars($row['VorlNr']); ?>" <?php echo (in_array($row['VorlNr'], $hört_vorlesungen)) ? 'checked' : ''; ?>></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
            <button type="submit">Änderungen übernehmen</button>
        </form>
        <p><a href="admin.php">Zurück zur Admin-Seite</a></p>
    </div>
</body>
</html>

<?php
// Datenbankverbindung schließen
mysqli_close($mysqli);
?>
