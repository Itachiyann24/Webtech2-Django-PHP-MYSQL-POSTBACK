<?php
// ZugangDB.php
$mysql_server = "localhost";
$mysql_user = "lamp";
$mysql_password = "thiewua7EiNg";
$mysql_dbname = "uni";


$mysqli= mysqli_connect($mysql_server,$mysql_user,$mysql_password,$mysql_dbname);
if(!$mysqli){
    die('Ddatenverbindung fehlgeschlagen : '.mysqli_connect_error());

}
?>
