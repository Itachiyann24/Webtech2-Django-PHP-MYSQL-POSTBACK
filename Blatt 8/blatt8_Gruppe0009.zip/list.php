<?php
session_start();

// Sicherstellen, dass der Benutzer eingeloggt ist
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: admin.php');
    exit;
}

// Datenbankverbindung einbinden
require_once 'db_connect.php';

// Studenten aus der Datenbank abrufen
$query = "SELECT MatrNr, Vorname, Nachname FROM Student";
$result = mysqli_query($mysqli, $query);

// Überprüfen, ob die Abfrage erfolgreich war
if (!$result) {
    die('Fehler bei der Abfrage: ' . mysqli_error($mysqli));
}
?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <title>Studentenliste</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="admin-container">
        <h2>Studentenliste</h2>
        <table>
            <thead>
                <tr>
                    <th>Matrikelnummer</th>
                    <th>Vorname</th>
                    <th>Nachname</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['MatrNr']); ?></td>
                        <td><?php echo htmlspecialchars($row['Vorname']); ?></td>
                        <td><?php echo htmlspecialchars($row['Nachname']); ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
        <a href="admin.php">Zurück zur Admin-Seite</a>
    </div>
</body>
</html>

<?php
// Ergebnis freigeben und Verbindung schließen
mysqli_free_result($result);
mysqli_close($mysqli);
?>
