<?php
session_start();

// Sicherstellen, dass der Benutzer eingeloggt ist
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: admin.php');
    exit;
}

// Datenbankverbindung einbinden
require_once 'db_connect.php';

// Initialisierung der Variablen für Fehlermeldungen und Erfolgsmeldungen
$error = '';
$success_message = '';

// Verarbeitung des Formulars bei POST-Request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $vorname = trim($_POST['vorname']);
    $nachname = trim($_POST['nachname']);

    // Validierung der Eingaben
    if (empty($vorname) || empty($nachname)) {
        $error = 'Bitte füllen Sie alle Felder aus.';
    } elseif (strlen($vorname) > 64 || strlen($nachname) > 64) {
        $error = 'Vorname und Nachname dürfen jeweils maximal 64 Zeichen lang sein.';
    } else {
        // SQL-Insert vorbereiten
        $insert_query = "INSERT INTO Student (Vorname, Nachname) VALUES (?, ?)";
        $stmt = mysqli_prepare($mysqli, $insert_query);
        mysqli_stmt_bind_param($stmt, 'ss', $vorname, $nachname);

        // SQL-Insert ausführen
        if (mysqli_stmt_execute($stmt)) {
            $success_message = 'Student erfolgreich hinzugefügt.';
        } else {
            $error = 'Fehler beim Hinzufügen des Studenten: ' . mysqli_stmt_error($stmt);
        }

        // Statement schließen
        mysqli_stmt_close($stmt);
    }
}
?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <title>Student hinzufügen</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="admin-container">
        <h2>Student hinzufügen</h2>
        <?php if (!empty($error)): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>
        <?php if (!empty($success_message)): ?>
            <p class="success"><?php echo htmlspecialchars($success_message); ?></p>
            <p><a href="http://scilab-0009.cs.uni-kl.de/ex08/list.php">Zurück zur Liste der Studenten</a></p>
        <?php else: ?>
            <form method="post" action="add.php">
                <label for="vorname">Vorname:</label>
                <input type="text" id="vorname" name="vorname" required maxlength="64">
                <br>
                <label for="nachname">Nachname:</label>
                <input type="text" id="nachname" name="nachname" required maxlength="64">
                <br>
                <button type="submit">Student hinzufügen</button>
            </form>
            <p><a href="admin.php">Zurück zur Admin-Seite</a></p>
        <?php endif; ?>
    </div>
</body>
</html>

<?php
// Datenbankverbindung schließen
mysqli_close($mysqli);
?>
