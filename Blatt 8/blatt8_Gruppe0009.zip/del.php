<?php
session_start();

// Sicherstellen, dass der Benutzer eingeloggt ist
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: admin.php');
    exit;
}

// Datenbankverbindung einbinden
require_once 'db_connect.php';

// Initialisierung der Variablen für Fehlermeldung und Erfolgsmeldung
$error = '';
$success_message = '';

// Verarbeitung des Formulars bei POST-Request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Überprüfen, ob eine Matrikelnummer übergeben wurde
    $matrnr = $_POST['matrnr'] ?? '';
    if (empty($matrnr)) {
        $error = 'Bitte geben Sie eine Matrikelnummer an.';
    } else {
        // Student aus der Datenbank löschen
        $delete_query = "DELETE FROM Student WHERE MatrNr = ?";
        $stmt_delete = mysqli_prepare($mysqli, $delete_query);
        mysqli_stmt_bind_param($stmt_delete, 'i', $matrnr);
        mysqli_stmt_execute($stmt_delete);

        if (mysqli_stmt_affected_rows($stmt_delete) > 0) {
            $success_message = 'Student erfolgreich gelöscht.';
        } else {
            $error = 'Es wurde kein Student mit dieser Matrikelnummer gefunden.';
        }

        mysqli_stmt_close($stmt_delete);
    }
}

?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <title>Student löschen</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="admin-container">
        <h2>Student löschen</h2>
        <?php if (!empty($error)): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>
        <?php if (!empty($success_message)): ?>
            <p class="success"><?php echo htmlspecialchars($success_message); ?></p>
            <p><a href="admin.php">Zurück zur Admin-Seite</a></p>
        <?php else: ?>
            <form method="post" action="del.php">
                <label for="matrnr">Matrikelnummer des zu löschenden Studenten:</label>
                <input type="number" id="matrnr" name="matrnr" required>
                <button type="submit">Student löschen</button>
            </form>
            <p><a href="admin.php">Zurück zur Admin-Seite</a></p>
        <?php endif; ?>
    </div>
</body>
</html>

<?php
// Datenbankverbindung schließen
mysqli_close($mysqli);
?>
