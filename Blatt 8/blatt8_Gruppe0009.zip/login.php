<?php
session_start();


function get_credentials() {
   
    return [
        'username' => 'admin',
        'password_hash' => password_hash('securepassword', PASSWORD_DEFAULT) 
    ];
}

// Überprüfen, ob das Formular abgesendet wurde
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    // Zugangsdaten abrufen
    $credentials = get_credentials();

    // Überprüfen, ob der Benutzername und das Passwort übereinstimmen
    if ($username === $credentials['username'] && password_verify($password, $credentials['password_hash'])) {
        // Anmeldung erfolgreich, Sitzung starten
        $_SESSION['loggedin'] = true;
        $_SESSION['username'] = $username;

        // Weiterleitung zur Administrationsseite
        header('Location: admin.php');
        exit;
    } else {
        // Fehlermeldung bei ungültigen Zugangsdaten
        $error = 'Ungültiger Benutzername oder Passwort.';
    }
}
?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <style>body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
}

.login-container, .admin-container {
    background-color: #fff;
    padding: 29px;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    width: 300px;
    text-align: center;
}

h2 {
    margin-top: 0;
}

label {
    display: block;
    margin-top: 10px;
}

input[type="text"], input[type="password"] {
    width: 100%;
    padding: 10px;
    margin-top: 5px;
    border: 1px solid #ccc;
    border-radius: 4px;
}

button {
    width: 100%;
    padding: 10px;
    background-color: #007bff;
    border: none;
    border-radius: 4px;
    color: white;
    font-size: 16px;
    margin-top: 10px;
    cursor: pointer;
}

button:hover {
    background-color: #0056b3;
}

.error {
    color: red;
    margin-top: 10px;
}

a {
    color: #007bff;
    text-decoration: none;
}

a:hover {
    text-decoration: underline;
}
 </style>
    <div class="login-container">
        <h2>Login</h2>
        <?php if (!empty($error)): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>
        <form method="post" action="login.php">
            <label for="username">Benutzername:</label>
            <input type="text" id="username" name="username" required>
            <br>
            <label for="password">Passwort:</label>
            <input type="password" id="password" name="password" required>
            <br>
            <button type="submit">Einloggen</button>
        </form>
    </div>
</body>
</html>
