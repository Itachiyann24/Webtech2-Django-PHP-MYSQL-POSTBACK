<?php
session_start();

// Sicherstellen, dass der Benutzer eingeloggt ist
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: admin.php');
    exit;
}

// Datenbankverbindung einbinden
require_once 'db_connect.php';

// Initialisierung der Variablen für Fehlermeldungen und Erfolgsmeldungen
$error = '';
$success_message = '';

// Verarbeitung des Formulars bei POST-Request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $matrnr = $_POST['matrnr'] ?? '';
    $vorname = $_POST['vorname'] ?? '';
    $nachname = $_POST['nachname'] ?? '';

    // Validierung der Eingaben (hier einfach Länge prüfen)
    if (strlen($vorname) > 64 || strlen($nachname) > 64) {
        $error = 'Vorname und Nachname dürfen maximal 64 Zeichen lang sein.';
    } else {
        // SQL-Update vorbereiten
        $query = "UPDATE Student SET Vorname = ?, Nachname = ? WHERE MatrNr = ?";
        
        // Vorbereiten und Ausführen des SQL-Statements
        $stmt = mysqli_prepare($mysqli, $query);
        mysqli_stmt_bind_param($stmt, 'ssi', $vorname, $nachname, $matrnr);
        
        if (mysqli_stmt_execute($stmt)) {
            // Erfolgsmeldung setzen
            $success_message = 'Änderungen erfolgreich gespeichert.';
        } else {
            // Fehlermeldung setzen
            $error = 'Fehler beim Speichern der Änderungen: ' . mysqli_stmt_error($stmt);
        }

        // Statement schließen
        mysqli_stmt_close($stmt);
    }
} else {
    // GET-Parameter verarbeiten, um die Daten des Studenten zu laden
    $matrnr = $_GET['matrnr'] ?? '';

    // SQL-Select vorbereiten
    $query = "SELECT Vorname, Nachname FROM Student WHERE MatrNr = ?";
    
    // Vorbereiten und Ausführen des SQL-Statements
    $stmt = mysqli_prepare($mysqli, $query);
    mysqli_stmt_bind_param($stmt, 'i', $matrnr);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_bind_result($stmt, $vorname, $nachname);

    // Ergebnis holen
    mysqli_stmt_fetch($stmt);

    // Statement schließen
    mysqli_stmt_close($stmt);
}

?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <title>Student bearbeiten</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="admin-container">
        <h2>Student bearbeiten</h2>
        <?php if (!empty($error)): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>
        <?php if (isset($success_message)): ?>
            <p class="success"><?php echo htmlspecialchars($success_message); ?></p>
        <?php endif; ?>
        <form method="post" action="edit.php">
            <input type="hidden" name="matrnr" value="<?php echo htmlspecialchars($matrnr); ?>">
            <label for="vorname">Vorname:</label>
            <input type="text" id="vorname" name="vorname" value="<?php echo htmlspecialchars($vorname); ?>" required>
            <br>
            <label for="nachname">Nachname:</label>
            <input type="text" id="nachname" name="nachname" value="<?php echo htmlspecialchars($nachname); ?>" required>
            <br>
            <button type="submit">Änderungen übernehmen</button>
        </form>
        <a href="admin.php">Zurück zur Admin-Seite</a>
    </div>
</body>
</html>

<?php
// Datenbankverbindung schließen
mysqli_close($mysqli);
?>
