<?php
session_start();

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: login.php');
    exit;
}


// ZugangDB.php
$mysql_server = "localhost";
$mysql_user = "lamp";
$mysql_password = "thiewua7EiNg";
$mysql_dbname = "uni";


$mysqli= mysqli_connect($mysql_server,$mysql_user,$mysql_password,$mysql_dbname);
if(!$mysqli){
    die('Ddatenverbindung fehlgeschlagen : '.mysqli_connect_error());

}
?>


<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <title>Administrations-Webfrontend</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="admin-container">
        <h2>Administrations-Webfrontend</h2>
        <ul>
            <li><a href="list.php">Studentenliste anzeigen</a></li>
            <li><a href="add.php">Neuen Studenten hinzufügen</a></li>
            <li><a href="edit.php">Student bearbeiten</a></li>
            <li><a href="del.php">Student löschen</a></li>
            <li><a href="assign.php">Vorlesungen zuweisen</a></li>
        </ul>
    </div>
</body>
</html>
