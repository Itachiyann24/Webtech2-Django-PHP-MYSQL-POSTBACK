<?php
 require_once '/home/lamp/bak/ZugangDB.php';


$conn = new mysqli($db_host, $db_user, $db_password, $db_name);


if ($conn->connect_error) {
    die("Verbindung zur MySQL-Datenbank fehlgeschlagen: " . $conn->connect_error);
} else{
    echo" Verbindung erfolgreich aufgebaut"
}


?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Studierenden Informationen</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        table {
            border-collapse: collapse;
            width: 50%;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <h1>Studierenden Informationen</h1>

    <?php
    
    if (isset($_GET['matrikelnr'])) {
        $matrikelnr = $_GET['matrikelnr'];

        
        $sql_student_info = "SELECT Vorname, Nachname FROM Student WHERE MatrNr = '$matrikelnr'";
        $result_student_info = $conn->query($sql_student_info);

        if ($result_student_info->num_rows > 0) {
            $student = $result_student_info->fetch_assoc();
            echo "<h2>Vorlesungen für {$student['Vorname']} {$student['Nachname']}</h2>";

            
            $sql_vorlesungen = "SELECT Vorlesung.Titel 
                                FROM hört 
                                JOIN Vorlesung ON hört.VorlNr = Vorlesung.VorlNr 
                                WHERE hört.MatrNr = '$matrikelnr'";

            $result_vorlesungen = $conn->query($sql_vorlesungen);

            if ($result_vorlesungen->num_rows > 0) {
                echo "<table>";
                echo "<tr><th>Vorlesungen</th></tr>";
                while($row = $result_vorlesungen->fetch_assoc()) {
                    echo "<tr><td>".$row["Titel"]."</td></tr>";
                }
                echo "</table>";
            } else {
                echo "Keine Vorlesungen gefunden.";
            }
        } else {
            echo "Studierender mit Matrikelnummer $matrikelnr nicht vorhanden!";
        }
    }
    ?>

</body>
</html>

<?php
$conn->close();
?>
