<?php session_start(); ?>
<!DOCTYPE html>
<html> <head> <!-- … --> </head> <body> 
<?php 

 // Wir zählen die Zahl der Aufrufe in dieser Session
 if (!isset($_SESSION['number_of_calls'])) {
 $_SESSION['number_of_calls'] = 0;
 } else {
 $_SESSION['number_of_calls']++;
 
 }
 // Timeout nach 3 Minuten ohne Aktivität
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > 180)) {
    session_unset(); // Session-Daten löschen
    session_destroy(); // Session beenden
}
 // Die Änderung an der Variablen wird sofort dauerhaft wirksam
?>
<p>Sie haben 
 <?php echo $_SESSION['number_of_calls']; ?> 
 Aufrufe in dieser Session gemacht.

 <br>
 <br>
aufgabe 3b: Jedes Mal, wenn der Benutzer die Seite aufruft, wird das Cookie erneuert und die Ablaufzeit auf weitere 3 Minuten in die Zukunft verschoben.
Der Timeout wird zurückgesetzt, da das Cookie/Session bei jedem Seitenaufruf mit einer neuen Ablaufzeit gesetzt wird.
</body>
</html>