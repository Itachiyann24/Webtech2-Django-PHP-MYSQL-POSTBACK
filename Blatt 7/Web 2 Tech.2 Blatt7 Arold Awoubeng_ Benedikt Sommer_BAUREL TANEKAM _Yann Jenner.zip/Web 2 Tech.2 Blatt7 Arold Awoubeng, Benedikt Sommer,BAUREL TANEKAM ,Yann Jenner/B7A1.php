<?php
function safe_output($array) {
    echo '<pre>';
    foreach ($array as $key => $value) {
        echo htmlspecialchars("$key => $value\n");
    }
    echo '</pre>';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['toggle_debug'])) {
    
    $current_debug = isset($_COOKIE['debug']) ? (int)$_COOKIE['debug'] : 0;
    $new_debug = $current_debug ? 0 : 1;
    setcookie('debug', $new_debug, time() + 3600, '/'); // Cookie gültig für 1 Stunde
    
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit();
}
?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <title>PHP Formulare und Cookies</title>
</head>
<body>
    <h1>Formular und Cookies</h1>
    <h2>GET-Daten</h2>
    <?php safe_output($_GET); ?>

    <h2>POST-Daten</h2>
    <?php safe_output($_POST); ?>

    <h2>COOKIE-Daten</h2>
    <?php safe_output($_COOKIE); ?>

    <?php if (@$_COOKIE['debug']) : ?>
        <h2>SERVER-Daten</h2>
        <?php safe_output($_SERVER); ?>
    <?php endif; ?>

    <h2>Client-Daten</h2>
    <?php
    $client_ip = htmlspecialchars($_SERVER['REMOTE_ADDR']);
    $client_port = htmlspecialchars($_SERVER['REMOTE_PORT']);
    $client_browser = htmlspecialchars($_SERVER['HTTP_USER_AGENT']);
    echo "<p>Client: IP-Adresse ist $client_ip auf Port $client_port. Der Browser heißt $client_browser.</p>";
    ?>

    <form action="" method="get">
        <input type="submit" name="details" value="Details zum Server anzeigen">
    </form>

    <?php
    if (isset($_GET['details'])) {
        echo '<h2>Server-Daten</h2>';
        $server_ip = htmlspecialchars($_SERVER['SERVER_ADDR']);
        $server_hostname = htmlspecialchars(gethostname());
        $server_software = htmlspecialchars($_SERVER['SERVER_SOFTWARE']);
        echo "<p>Server: IP-Adresse ist $server_ip, Hostname $server_hostname. Webserver-Software ist $server_software.</p>";
    }
    ?>

    <form action="" method="post">
        <input type="submit" name="toggle_debug" value="Debug-Modus umschalten">
    </form>
</body>
</html>
