<?php
 
$cookie_expiration  = time() + 180;
 // Wir zählen die Zahl der Aufrufe dieses Clients in Cookies
 if (!isset($_COOKIE['number_of_calls'])) 
 // cookie war ungesetzt → setze Startwert
 $number_of_calls = 0;
 else
 $number_of_calls = $_COOKIE['number_of_calls'] + 1;
 setcookie('number_of_calls', $number_of_calls,$cookie_expiration);
?>
<!DOCTYPE html>
<html> <head> <!-- … --> </head> 
<body>
<p>Sie haben
 <?php echo $number_of_calls; ?>
 Aufrufe gemacht.

</body> 
</html>