<?php
if (isset($_GET['zitat'])) {
    $zitat = $_GET['zitat'];
    $teile = explode('/', $zitat);
    $zitat_text = implode(' ', $teile);
    echo "<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <title>Zitate</title>
</head>
<body>
    <h1>Zitat des Tages:</h1>
    <p>$zitat_text</p>
</body>
</html>";
} else {
    echo "<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <title>Zitate</title>
</head>
<body>
    <h1>Kein Zitat gefunden</h1>
</body>
</html>";
}
?>
