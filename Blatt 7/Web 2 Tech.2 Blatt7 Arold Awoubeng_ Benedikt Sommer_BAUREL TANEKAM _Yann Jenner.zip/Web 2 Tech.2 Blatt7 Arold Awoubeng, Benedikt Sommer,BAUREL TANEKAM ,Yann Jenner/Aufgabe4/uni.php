<?php
// Inkludiere die DB-Konfigurationsdatei
include 'db_config.php';

// Verbindung zur Datenbank aufbauen
try {
    $dsn = "mysql:host=$host;dbname=$dbname;charset=utf8mb4";
    $pdo = new PDO($dsn, $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "Verbindung zur Datenbank erfolgreich hergestellt.";
} catch (PDOException $e) {
    echo "Fehler bei der Verbindung zur Datenbank: " . $e->getMessage();
    exit;
}

// Funktion, um alle Studierenden und ihre Vorlesungen anzuzeigen
function displayStudents($pdo, $matrikelnr = null) {
    // SQL-Abfrage erstellen
    if ($matrikelnr) {
        $stmt = $pdo->prepare("SELECT s.matrikelnr, s.vorname, s.nachname, GROUP_CONCAT(v.titel SEPARATOR ', ') as vorlesungen 
                               FROM studenten s
                               LEFT JOIN hoert h ON s.matrikelnr = h.matrikelnr
                               LEFT JOIN vorlesung v ON h.vorlesungsnr = v.vorlesungsnr
                               WHERE s.matrikelnr = ?
                               GROUP BY s.matrikelnr, s.vorname, s.nachname");
        $stmt->execute([$matrikelnr]);
    } else {
        $stmt = $pdo->query("SELECT s.matrikelnr, s.vorname, s.nachname, GROUP_CONCAT(v.titel SEPARATOR ', ') as vorlesungen 
                             FROM studenten s
                             LEFT JOIN hoert h ON s.matrikelnr = h.matrikelnr
                             LEFT JOIN vorlesung v ON h.vorlesungsnr = v.vorlesungsnr
                             GROUP BY s.matrikelnr, s.vorname, s.nachname");
    }
    
    // Ergebnisse anzeigen
    if ($stmt->rowCount() > 0) {
        echo '<table border="1">';
        echo '<tr><th>Matrikelnr</th><th>Vorname</th><th>Nachname</th><th>Vorlesungen</th></tr>';
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            echo '<tr>';
            echo '<td>' . htmlspecialchars($row['matrikelnr']) . '</td>';
            echo '<td>' . htmlspecialchars($row['vorname']) . '</td>';
            echo '<td>' . htmlspecialchars($row['nachname']) . '</td>';
            echo '<td>' . htmlspecialchars($row['vorlesungen']) . '</td>';
            echo '</tr>';
        }
        echo '</table>';
    } else {
        echo 'Studierender mit Matrikelnummer ' . htmlspecialchars($matrikelnr) . ' nicht vorhanden!';
    }
}

// Überprüfen, ob eine Matrikelnummer übergeben wurde
$matrikelnr = isset($_GET['matrikelnr']) ? $_GET['matrikelnr'] : null;
displayStudents($pdo, $matrikelnr);
?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <title>Studierende der Uni</title>
    <style>
        /* Einfache CSS-Formatierungen */
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            padding: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #333;
            color: white;
        }
        td {
            background-color: #fff;
        }
        form {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <h1>Studierende der Uni</h1>
    <!-- Formular zur Eingabe der Matrikelnummer -->
    <form action="uni.php" method="get">
        <label for="matrikelnr">Matrikelnummer:</label>
        <input type="text" id="matrikelnr" name="matrikelnr">
        <button type="submit">Suchen</button>
    </form>
    <!-- Ausgabe der Daten erfolgt hier -->

    

c. Es ist sinnvoll, der Datei die Endung .php zu geben und sie außerhalb des htdocs-Verzeichnisses zu platzieren, weil PHP-Dateien vom Server interpretiert werden und deren Inhalt nicht direkt im Browser angezeigt wird. So bleiben die Zugangsdaten sicher und können nicht von außen eingesehen werden.
e. In der SQL-Abfrage wird GROUP_CONCAT verwendet, um die Vorlesungen eines Studierenden als kommaseparierte Liste in einer Spalte darzustellen.
f. Wenn eine Matrikelnummer über die URL als GET-Parameter übermittelt wird, wird die SQL-Abfrage entsprechend angepasst, um nur die Daten des entsprechenden Studierenden anzuzeigen.

</body>
</html>


