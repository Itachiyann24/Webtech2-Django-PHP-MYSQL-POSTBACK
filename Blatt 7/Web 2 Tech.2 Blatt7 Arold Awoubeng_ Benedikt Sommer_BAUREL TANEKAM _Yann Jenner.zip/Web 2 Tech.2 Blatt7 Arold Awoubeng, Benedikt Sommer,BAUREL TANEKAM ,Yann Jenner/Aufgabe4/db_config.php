<?php
$host = 'localhost';
$dbname = 'uni';
$username = 'db_user';
$password = 'db_pass';
?>
