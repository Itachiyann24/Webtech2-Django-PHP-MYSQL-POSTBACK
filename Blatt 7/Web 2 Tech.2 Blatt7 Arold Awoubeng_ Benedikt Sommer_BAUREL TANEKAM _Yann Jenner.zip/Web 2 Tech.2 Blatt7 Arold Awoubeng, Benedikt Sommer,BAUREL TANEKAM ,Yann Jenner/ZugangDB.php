<?php
$db_host = 'localhost';
$db_user = 'lamp';
$db_password = 'thiewua7EiNg';
$db_name = 'uni';



// es ist sinnvoll die DAtei mit .php enden zu lassen , da die Datei php- code enthält und 
//dieser vom Webserver interpretiert wird. DAdurch wird verhindert , dass der Inhalt im Browser angeziegt wird.
  ?>