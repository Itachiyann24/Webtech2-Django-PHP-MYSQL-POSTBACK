<?php
$username = $password = "";
$usernameErr = $passwordErr = "";
$hashedPassword = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validierung für Benutzername
    if (empty($_POST["username"])) {
        $usernameErr = "Benutzername ist erforderlich";
    } elseif (!filter_var($_POST["username"], FILTER_VALIDATE_EMAIL) || !preg_match("/@rptu\.de$/", $_POST["username"])) {
        $usernameErr = "Der Benutzername muss eine gültige Universitäts-Email-Adresse (rptu.de) sein";
    } else {
        $username = htmlspecialchars($_POST["username"]);
    }

    // Validierung für Passwort
    if (empty($_POST["password"])) {
        $passwordErr = "Passwort ist erforderlich";
    } elseif (strlen($_POST["password"]) < 12 || 
              !preg_match("/[A-Za-z]/", $_POST["password"]) || 
              !preg_match("/[0-9]/", $_POST["password"]) || 
              !preg_match("/[\W]/", $_POST["password"])) {
        $passwordErr = "Das Passwort muss mindestens 12 Zeichen lang sein und sowohl Buchstaben als auch Zahlen und Sonderzeichen enthalten";
    } else {
        $password = $_POST["password"];
    }

    // Wenn keine Fehler vorhanden sind, Benutzername und gehashtes Passwort anzeigen
    if (empty($usernameErr) && empty($passwordErr)) {
        $salt = bin2hex(random_bytes(16)); // 16 bytes = 128 bits, hex kodiert = 32 chars
        $hashedPassword = password_hash($password . $salt, PASSWORD_DEFAULT);
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Registrierung</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 50px;
        }
        .form-container {
            margin: auto;
            width: 50%;
            padding: 10px;
            border: 1px solid #ccc;
            box-shadow: 2px 2px 10px #aaa;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            margin-bottom: 5px;
        }
        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 8px;
            box-sizing: border-box;
        }
        input[type="submit"] {
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
        }
        .error {
            color: red;
            font-size: 0.9em;
        }
    </style>
</head>
<body>
<div class="form-container">
    <h2>Registrierung</h2>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <div class="form-group">
            <label for="username">Benutzername (Universitäts-Email):</label>
            <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($username); ?>" required>
            <span class="error"><?php echo $usernameErr; ?></span>
        </div>
        <div class="form-group">
            <label for="password">Passwort:</label>
            <input type="password" id="password" name="password" required>
            <span class="error"><?php echo $passwordErr; ?></span>
        </div>
        <input type="submit" value="Registrieren">
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST" && empty($usernameErr) && empty($passwordErr)) {
        echo "<h3>Erfolgreiche Registrierung</h3>";
        echo "<p>Benutzername: " . htmlspecialchars($username) . "</p>";
        echo "<p>Gehashtes Passwort: " . htmlspecialchars($hashedPassword) . "</p>";
    }
    ?>
</div>
</body>
</html>
