<?php
$error_text = $error_repeats = "";
$text = "";
$repeats = 42; // Standardwert

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $text = trim($_POST["text"]);
    $repeats = intval($_POST["repeats"]);

    
    if (strlen($text) < 5 || strlen($text) > 256) {
        $error_text = "Der Text muss mindestens 5 und maximal 256 Zeichen lang sein.";
    }
    if ($repeats < 2 || $repeats > 100) {
        $error_repeats = "Die Anzahl der Wiederholungen muss zwischen 2 und 100 liegen.";
    }

    
    if (empty($error_text) && empty($error_repeats)) {
        echo "<!DOCTYPE html>
        <html>
        <head>
        <title>Strafarbeiten</title>
        <style>
            body {
                background-color: #3B5323;
                color: white;
                font-family: 'Courier New', Courier, monospace;
            }
            .board {
                border: 10px solid #8B4513;
                padding: 20px;
                background-color: #3B5323;
                color: white;
                width: 80%;
                margin: auto;
                text-align: center;
            }
        </style>
        </head>
        <body>
        <div class='board'>";
        for ($i = 0; $i < $repeats; $i++) {
            echo htmlspecialchars($text) . "<br>";
        }
        echo "</div>
        </body>
        </html>";
        exit;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Bart Simpsons Strafarbeiten</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 50px;
        }
        .error {
            color: red;
            font-size: 0.9em;
        }
        .form-container {
            margin: auto;
            width: 50%;
            padding: 10px;
            border: 1px solid #ccc;
            box-shadow: 2px 2px 10px #aaa;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            margin-bottom: 5px;
        }
        input[type="text"], input[type="number"], textarea {
            width: 100%;
            padding: 8px;
            box-sizing: border-box;
        }
        input[type="submit"] {
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
        }
    </style>
</head>
<body>
<div class="form-container">
    <h2>Bart Simpsons Strafarbeiten</h2>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <div class="form-group">
            <label for="text">Strafarbeiten-Text:</label>
            <textarea id="text" name="text" minlength="5" maxlength="256" required><?php echo htmlspecialchars($text); ?></textarea>
            <span class="error"><?php echo $error_text; ?></span>
        </div>
        <div class="form-group">
            <label for="repeats">Anzahl der Wiederholungen:</label>
            <input type="number" id="repeats" name="repeats" min="2" max="100" value="<?php echo
             htmlspecialchars($repeats); ?>" required>
            <span class="error"><?php echo $error_repeats; ?></span>
        </div>
        <input type="submit" value="Generieren">
    </form>
</div>
</body>
</html>
