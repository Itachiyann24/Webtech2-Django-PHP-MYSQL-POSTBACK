<?php

$count = isset($_GET['count']) ? intval($_GET['count']) : 0;

$url = "?count=" . ($count + 1);
?>
<!DOCTYPE html>
<html>
<head>
<title>Counter (<?php echo htmlspecialchars($count); ?>)</title>
<meta http-equiv="refresh" content="2; URL=<?php echo htmlspecialchars($url); ?>">
</head>
<body>
<h1>Count: <?php echo htmlspecialchars($count); ?></h1>
<?php echo htmlspecialchars(date('s')); ?>
</body>
</html>
