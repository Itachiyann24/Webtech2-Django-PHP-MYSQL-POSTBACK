<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wetter</title>
</head>
<style>
    body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f9;
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
}

h1 {
    text-align: center;
    color: #333;
    font size : Time New Roman, Arial:
}

form {
    background-color: #fff;
    padding: 20px;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

table {
    width: 100%;
    border-collapse: collapse;
    margin: 20px 0;
}

td {
    padding: 10px;
    vertical-align: top;
}

select, input[type="radio"], input[type="checkbox"], input[type="submit"] {
    margin-top: 5px;
}

input[type="submit"] {
    background-color: #4CAF50;
    color: white;
    border: none;
    padding: 10px 20px;
    border-radius: 5px;
    cursor: pointer;
    text-transform: uppercase;
    letter-spacing: 1px;
}

input[type="submit"]:hover {
    background-color: #45a049;
}

optgroup {
    font-weight: bold;
    color: #333;
}

option {
    padding: 5px;
}

</style>
<body>
    <h1>Wetter von Städte</h1>
    
    <form method="GET" action="B6A3.php">
        <table>
            <tr>
                <td>
                <select name="ort">
                    <option value="New York">New York</option>
                    <option value="Tokio">Tokio</option>
                    <option value="London">London</option>
                    <option value="Kaiserslautern">Kaiserslautern</option>
                </select>
                </td>
            </tr>
            <tr>
            <td>Datum:</td>
            <td>
                <select name="datum">
                    <?php
                    $months = [
                        "Januar" => 1,
                        "Februar" => 2,
                        "März" => 3,
                        "April" => 4,
                        "Mai" => 5,
                        "Juni" => 6,
                        "Juli" => 7,
                        "August" => 8,
                        "September" => 9,
                        "Oktober" => 10,
                        "November" => 11,
                        "Dezember" => 12
                    ];

                    foreach ($months as $monthName => $monthNumber) {
                        echo "<optgroup label=\"$monthName\">";
                        for ($day = 1; $day <= 30; $day++) {
                            $dateValue = "$day.$monthNumber.";
                            $selected = ($dateValue == "7.3.") ? "selected" : "";
                            echo "<option value=\"$dateValue\" $selected>$day.$monthNumber.</option>";
                        }
                        echo "</optgroup>";
                    }
                    ?>
                </select>
            </td>
        </tr>
        <tr>
            <td>Wetter:</td>
            <td>
                <input type="radio" name="wetter" value="Sonne"> Sonne<br>
                <input type="radio" name="wetter" value="Regen"> Regen<br>
                <input type="radio" name="wetter" value="Schnee"> Schnee
            </td>
        </tr>
        <tr>
            <td>Zusatzoptionen:</td>
            <td>
                <input type="checkbox" name="windig" checked> Windig<br>
                <input type="checkbox" name="neblig"> Neblig<br>
                <input type="checkbox" name="langweilig"> Langweilig
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <input type="submit" value="Absenden">
            </td>
        </tr>
        </table>
    </form>
</body>
</html>