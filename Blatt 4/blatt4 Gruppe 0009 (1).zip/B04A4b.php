<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <title>Bart Simpson Strafe</title>
    <style>
        body {
            background-color: brown;
            display: flex;
            justify-content: center;
            align-items: center;
            /*height: 100vh; */
            margin: 0;
        }
        .tafel {
            background-color: black;
            color: white;
            font-family: 'Comic Sans MS', 'Chalkboard', sans-serif;
            padding: 20px;
            border: 10px solid brown;
            width: 80%;
            box-sizing: border-box;
        }
        .line {
            margin: 5px 0;
        }
    </style>
</head>
<body>
    <div class="tafel">
        <?php
        for ($i = 0; $i < 42; $i++) {
            $written = $i + 1;
            $remaining = 42 - $written;
            echo "<div class='line'>{$written}. Ich werde keine Kreide verschwenden! (nur noch {$remaining} mal …)</div>";
        }
        ?>
    </div>
</body>
</html>
